import sys,pygame
import tkinter
import drawning_elements
import global_variables
pygame.init()

pygame.display.set_caption('Least squares method')

#rrrewrewrew
def app_runner():

    while global_variables.running:
        for event in pygame.event.get():
            if event==pygame.QUIT:

                pygame.quit()
                exit(0)

        global_variables.window.fill(global_variables.color_for_background_rgb)

        drawning_elements.draw_background_lines()
        drawning_elements.draw_axis_for_x_y()

        global_variables.window.blit(global_variables.add_point_text_surface,global_variables.add_point_text_rect.topleft)

        pygame.display.flip()
        global_variables.clock.tick(60)

app_runner()


