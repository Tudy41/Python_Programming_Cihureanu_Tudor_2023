
import global_variables
import pygame

pygame.init()


def draw_background_lines():
    x_hor = 0
    x_ver = 0
    y_hor = 0
    y_ver = 0

    for it in range(1, 15):
        x_ver = it * global_variables.window_length // 9
        y_ver = 0

        pygame.draw.line(
            global_variables.window,
            (255, 255, 255),
            (x_ver, y_ver),
            (x_ver, global_variables.window_height)
        )

        x_hor = 0
        y_hor = it * global_variables.window_height // 9

        pygame.draw.line(
            global_variables.window,
            (255, 255, 255),
            (x_hor, y_hor),
            (global_variables.window_length, y_hor)
        )


def draw_axis_for_x_y():
    pygame.draw.line(global_variables.window,(255,255,255),(0,global_variables.window_height//2),(global_variables.window_length,global_variables.window_height//2))
    pygame.draw.line(global_variables.window,(255,255,255),(global_variables.window_length//2,0),(global_variables.window_length//2,global_variables.window_height))
    x_sign=global_variables.font.render('X',True,(255,255,255))
    y_sign=global_variables.font.render('Y', True,  (255, 255, 255))
    global_variables.window.blit(x_sign,(global_variables.window_length-23,global_variables.window_height//2-32))
    global_variables.window.blit(y_sign,(global_variables.window_length//2+10,10))
    step_x=global_variables.window_length//10
    step_y=global_variables.window_height//10
    for i in range(1,15):
        value_x=int((i*step_x-global_variables.window_length//2)/global_variables.zoom)
        value_y=int((global_variables.window_height//2-i*step_y)/global_variables.zoom)
        value_sign=global_variables.font.render(repr(value_x),True,(255,255,255))
        global_variables.window.blit(value_sign,(i*step_x+5,global_variables.window_height//2+5))
        value_sign=global_variables.font.render(repr(value_y),True,(255,255,255))
        global_variables.window.blit(value_sign,(global_variables.window_length//2+5,i*step_y+5))

def draw_text_box_input():
    pygame.draw.rect(global_variables.window, global_variables.color_text, global_variables.text_box_window, 2)
    global_variables.text_box_txt_inserted_zone = global_variables.font.render(f'{global_variables.text_inserted}', True, (255, 255, 255))
    global_variables.text_place = global_variables.text_box_txt_inserted_zone.get_rect(  midbottom=(global_variables.text_box_window.centerx, global_variables.text_box_window.centery + 15))
    global_variables.window.blit(global_variables.text_box_txt_inserted_zone, global_variables.text_place)
def draw_current_points():
    for p in global_variables.list_points:
        px, py = p
        window_x =  int(px *global_variables. zoom +global_variables. window_length // 2)
        window_y = int(global_variables.window_height // 2 - py * global_variables.zoom)
        pygame.draw.circle(global_variables.window, (0, 0, 255), (window_x, window_y), 6)


def show_coords_above_points():
    for p in global_variables.list_points:
        x=p[0]
        y=p[1]
        window_x=int(x*global_variables.zoom+global_variables.window_length//2)
        window_y=int(global_variables.window_height//2-y*global_variables.zoom)
        point_rect=pygame.Rect(window_x-10,window_y-10,20,20)
        if point_rect.collidepoint((pygame.mouse.get_pos())):
            coordinates_text=global_variables.font.render(f'({x:.3f},{y:.3f})',True,(255,255,255))
            text_rect=coordinates_text.get_rect(center=(window_x,window_y-20))
            global_variables.window.blit(coordinates_text,text_rect.topleft)

def draw_reset_btn():
    pygame.draw.rect(global_variables.window, global_variables.reset_color,  global_variables.reset_btn, 0)
    reset_text = global_variables.font.render("Reset", True, (255, 255, 255))
    global_variables.window.blit(reset_text, (global_variables.reset_btn.x + 10, global_variables.reset_btn.y + 5))

def draw_save_btn():
    pygame.draw.rect(global_variables.window, global_variables.save_color, global_variables.save_btn, 0)
    save_text = global_variables.font.render("Save", True, (255, 255, 255))
    global_variables.window.blit(save_text, (global_variables.save_btn.x + 10, global_variables.save_btn.y + 5))

def draw_connecting_lines():
    sorted_points = sorted(global_variables.list_points, key=lambda p: p[0])
    for i in range(len(sorted_points) - 1):
        x1, y1 = sorted_points[i]
        x2, y2 = sorted_points[i + 1]
        window_x1 = int(x1 * global_variables.zoom + global_variables.window_length // 2)
        window_y1 = int(global_variables.window_height  // 2 - y1 * global_variables.zoom)
        window_x2 = int(x2 * global_variables.zoom + global_variables.window_length // 2)
        window_y2 =  int(global_variables.window_height // 2 - y2 * global_variables.zoom)
        pygame.draw.line(global_variables.window, (0, 255, 0), (window_x1,  window_y1), (window_x2, window_y2), 2)