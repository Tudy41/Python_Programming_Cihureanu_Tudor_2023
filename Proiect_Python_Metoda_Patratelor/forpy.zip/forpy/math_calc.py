import global_variables
import pygame
m = 0
c = 0

def get_total(lst):
    total = 0
    for i in lst:
        total += i
    return total


def calculate_line(lst_points):
    aux1 = []
    aux2 = []
    aux3 = []
    aux4 = []

    if len(lst_points) > 1:
        nr = len(lst_points)

        for it in lst_points:
            aux1.append(get_total([it[0]]))
            aux2.append(get_total([it[1]]))
            aux3.append(get_total([it[0] * it[1]]))
            aux4.append(get_total([it[0] * it[0]]))

        sum_x = get_total(aux1)
        sum_y = get_total(aux2)
        sum_x_y = get_total(aux3)
        sum_x_squared = get_total(aux4)

        global m, c
        m = (nr * sum_x_y - sum_x * sum_y) / (nr * sum_x_squared - sum_x * sum_x)
        c = (sum_y - m * sum_x) / nr

        results = (m, c)
        return results

    return None


def draw_line_on_window(lst_points):
    m_and_c = calculate_line(lst_points)

    if m_and_c is not None:
        m, c = m_and_c

        x1 = -global_variables.window_length // 2
        y1 = m * (-global_variables.window_length // 2) + c

        x2 = global_variables.window_length // 2
        y2 = m * (global_variables.window_length // 2) + c

        pygame.draw.line(global_variables.window, (255, 0, 0), (0, int(global_variables.window_height // 2 - y1 * global_variables.zoom)),
                         (global_variables.window_length, int(global_variables.window_height // 2 - y2 * global_variables.zoom)), 2)

        text_eq = f"Equation: y = {m:.3f}x + {c:.3f}"
        eq_plane = global_variables.font.render(text_eq, True, (255, 255, 255))
        global_variables.window.blit(eq_plane, (20, 20))


