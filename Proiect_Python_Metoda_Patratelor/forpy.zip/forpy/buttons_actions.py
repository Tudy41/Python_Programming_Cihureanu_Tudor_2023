import tkinter
import global_variables
import pygame
from tkinter import filedialog

pygame.init()


def reset():
    global_variables.list_points.clear()
    global_variables.zoom = 1.0


def save():
    tkinter.Tk().withdraw()
    path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png")])

    if path:
        pygame.image.save(global_variables.window, path)
