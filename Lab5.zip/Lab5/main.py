print("ex1:\n")


class Shape:
    def area(self):
        pass

    def perimeter(self):
        pass


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14 * self.radius ** 2

    def perimeter(self):
        return 2 * 3.14 * self.radius


class Rectangle(Shape):
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * (self.length + self.width)


class Triangle(Shape):
    def __init__(self, side1, side2, side3):
        self.side1 = side1
        self.side2 = side2
        self.side3 = side3

    def area(self):
        s = (self.side1 + self.side2 + self.side3) / 2
        return (s * (s - self.side1) * (s - self.side2) * (s - self.side3)) ** 0.5

    def perimeter(self):
        return self.side1 + self.side2 + self.side3


circle = Circle(5)
print("Circle Area:", circle.area())
print("Circle Perimeter:", circle.perimeter())

print("ex2:\n")


class Account:
    def __init__(self, balance=0):
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
        else:
            print("Insufficient funds.")

    def calculate_interest(self):
        pass


class SavingsAccount(Account):
    def calculate_interest(self):
        return 0.02 * self.balance


class CheckingAccount(Account):
    def calculate_interest(self):
        return 0.01 * self.balance



savings_account = SavingsAccount(1000)
savings_account.deposit(500)
print("Savings Account Balance:", savings_account.balance)
savings_account.withdraw(200)
print("Savings Account Balance after withdrawal:", savings_account.balance)
print("Interest Earned:", savings_account.calculate_interest())

print("ex3:\n")


class Vehicle:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year

    def calculate_mileage(self):
        pass
    def calculate_towing_capacity(self):
        return "5000 pounds"

class Car(Vehicle):
    def calculate_mileage(self):
        return "25 miles per gallon"

class Motorcycle(Vehicle):
    def calculate_mileage(self):
        return "50 miles per gallon"


class Truck(Vehicle):
    def calculate_towing_capacity(self):
        return "5000 pounds"



car = Car("Toyota", "Camry", 2022)
print("Car Mileage:", car.calculate_mileage())
motorcicle=Motorcycle(50,50,50)
motorcicle.calculate_towing_capacity()
print("ex4:\n")


class Employee:
    def __init__(self, salary):
        self.salary = salary

    def perform_duties(self):
        pass


class Manager(Employee):
    def perform_duties(self):
        return "Manages the team and projects."
    def managepeople(self,):


class Engineer(Employee):
    def perform_duties(self):
        return "Designs and develops software."
    def code(self):
        return "im coding!"

class Salesperson(Employee):
    def perform_duties(self):
        return "Sells products or services."
    def sales(self):
        return "im selling!"


manager = Manager(80000)
print("Manager duties:", manager.perform_duties())

print("ex5:\n")


class Animal:
    def __init__(self, species):
        self.species = species

    def make_sound(self):
        pass


class Mammal(Animal):
    def give_birth(self):
        return "Give birth"


class Bird(Animal):
    def lay_eggs(self):
        return "Lays eggs"


class Fish(Animal):
    def breathe_underwater(self):
        return "Breathes underwater"


bird = Bird("Eagle")
print("Bird Species:", bird.species)
print("Reproduction Method:", bird.lay_eggs())

print("ex6:\n")


class LibraryItem:
    def __init__(self, title, author, year):
        self.title = title
        self.author = author
        self.year = year
        self.checked_out = False

    def check_out(self):
        if not self.checked_out:
            self.checked_out = True
            return "Item checked out successfully."
        else:
            return "Item is already checked out."

    def return_item(self):
        if self.checked_out:
            self.checked_out = False
            return "Item returned successfully."
        else:
            return "Item is not checked out."

    def display_info(self):
        return f"Title: {self.title}, Author: {self.author}, Year: {self.year}, Checked Out: {self.checked_out}"


class Book(LibraryItem):
    def __init__(self, title, author, year, genre):
        super().__init__(title, author, year)
        self.genre = genre


class DVD(LibraryItem):
    def __init__(self, title, director, year, duration):
        super().__init__(title, director, year)
        self.duration = duration


class Magazine(LibraryItem):
    def __init__(self, title, publisher, year, issue_number):
        super().__init__(title, publisher, year)
        self.issue_number = issue_number


book = Book("A journey to the center of the Earth", "J. Verne", 1870, "Fiction")
print(book.display_info())
print(book.check_out())
print(book.display_info())
print(book.return_item())
print(book.display_info())
