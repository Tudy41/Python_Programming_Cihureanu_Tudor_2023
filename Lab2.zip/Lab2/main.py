print("ex1:\n")


def fibo(n):
    s = [0, 1]
    while len(s) < n:
        a = s[-1] + s[-2]
        s.append(a)
    return s[:n]


print(fibo(10))
print("ex2:\n")


def prim(num):
    if num < 2:
        return False
    for i in range(2, num):
        if num % i == 0:
            return False
    return True


def numereprime(numere):
    list1 = []
    for n in numere:
        if prim(n):
            list1.append(n)
    return list1


print(numereprime([1, 2, 3, 4, 5, 6, 7, 8, 9]))

print("ex3:\n")


def operatii(a, b):
    intersectie = []
    reuniune = []
    diferenta_a = []
    diferenta_b = []
    for i in a:
        if i in b:
            intersectie.append(i)
        else:
            diferenta_a.append(i)
        reuniune.append(i)
    for i in b:
        if i not in a:
            diferenta_b.append(i)
    return intersectie, reuniune, diferenta_a, diferenta_b


l1 = [1, 2, 3, 4, 5]
l2 = [3, 4, 5, 6, 7]
print(operatii(l1, l2))

print("ex4:\n")


def compune(note, mutari, start):
    melodie = []
    index = start
    for mutare in mutari:
        index = (index + mutare) % len(note)
        melodie.append(note[index])
    return melodie


note = ["do", "re", "mi", "fa", "sol"]

mutari = [1, -3, 4, 2]
start = 2

print(compune(note, mutari, start))

print("ex5:\n")


def replace(m):
    for i in range(len(m)):
        for j in range(len(m[i])):
            if j < i:
                m[i][j] = 0
    return m


m = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(replace(m))

print("ex6:\n")


def repetari(x, *liste):
    contor = {}
    for i in liste:
        for j in i:
            if j in contor:
                contor[j] += 1
            else:
                contor[j] = 1
    rezultat = []
    for elem, numar in contor.items():
        if numar == x:
            rezultat.append(elem)
    return rezultat


lista1 = [1, 2, 3]
lista2 = [2, 3, 4]
lista3 = [4, 5, 6]
lista4 = [4, 1, "test"]
x = 2
print(repetari(x, lista1, lista2, lista3, lista4))

print("ex7:\n")


def palindrom(n):
    nstrstring = str(n)
    return nstrstring == nstrstring[::-1]


def palindroame(numere):
    numere_palindrom = 0
    cel_mai_mare_palindrom = None
    for num in numere:
        if palindrom(num):
            numere_palindrom += 1
            if cel_mai_mare_palindrom is None or num > cel_mai_mare_palindrom:
                cel_mai_mare_palindrom = num
    return numere_palindrom, cel_mai_mare_palindrom


numere = [121, 123, 1331, 555, 12321]
print(palindroame(numere))

print("ex8:\n")


def caractere(x, strings, flag):
    result = []
    for string in strings:
        filtered_chars = []
        for char in string:
            if (flag and ord(char) % x == 0) or (not flag and ord(char) % x != 0):
                filtered_chars.append(char)
        result.append(filtered_chars)
    return result



x = 2
siruri = ["test", "hello", "lab002"]
flag = False
print(caractere(x, siruri, flag))


print("ex10:\n")


def imbinare(*liste):
    max_len = max(len(l) for l in liste)
    return [tuple(l[i] if i < len(l) else None for l in liste) for i in range(max_len)]


l1 = [1, 2, 3]
l2 = [5, 6, 7]
l3 = ["a", "b", "c"]
rezultat = imbinare(l1, l2, l3)
print(rezultat)

print("ex11:\n")


def sortare_tuple(tuple_list):
    return sorted(tuple_list, key=lambda t: (t[1][2], t[0]))



tupluri = [('abc', 'bcd'), ('abc', 'zza')]
tupluri_sortate = sortare_tuple(tupluri)
print(tupluri_sortate)

print("ex12:\n")


def rimefunction(cuvinte):
    rime = {}
    for cuvant in cuvinte:
        sfarsit = cuvant[-2:]
        if sfarsit in rime:
            rime[sfarsit].append(cuvant)
        else:
            rime[sfarsit] = [cuvant]
    grupuri = list(rime.values())
    return grupuri


cuvinte = ['ana', 'banana', 'carte', 'arme', 'parte']
print(rimefunction(cuvinte))
