import os
import sys

def display_file_contents(directory, target_extension):
    try:
        files = [file for file in os.listdir(directory) if file.endswith(target_extension)]
        for file in files:
            file_path = os.path.join(directory, file)
            with open(file_path, 'r') as file_content:
                content = file_content.read()
                print(f"Contents of {file}:")
                print(content)
    except FileNotFoundError:
        print(f"Error: Directory '{directory}' not found.")
    except OSError as e:
        print(f"Error: {e}")

def rename_files_with_sequence(directory):
    try:
        files = os.listdir(directory)
        for i, file in enumerate(files, start=1):
            old_path = os.path.join(directory, file)
            new_name = f"file{i}.{file.split('.')[-1]}"
            new_path = os.path.join(directory, new_name)
            os.rename(old_path, new_path)
    except FileNotFoundError:
        print(f"Error: Directory '{directory}' not found.")
    except OSError as e:
        print(f"Error: {e}")

def calculate_total_directory_size(directory):
    try:
        total_size = 0
        for foldername, subfolders, filenames in os.walk(directory):
            for filename in filenames:
                file_path = os.path.join(foldername, filename)
                total_size += os.path.getsize(file_path)
        print(f"Total size of all files in {directory}: {total_size} bytes")
    except FileNotFoundError:
        print(f"Error: Directory '{directory}' not found.")
    except PermissionError:
        print(f"Error: Permission denied for '{directory}'.")
    except OSError as e:
        print(f"Error: {e}")

def count_files_by_extension(directory):
    try:
        extension_count = {}
        for filename in os.listdir(directory):
            _, extension = os.path.splitext(filename)
            extension = extension.lower()
            extension_count[extension] = extension_count.get(extension, 0) + 1

        for ext, count in extension_count.items():
            print(f"Number of .{ext} files: {count}")
    except FileNotFoundError:
        print(f"Error: Directory '{directory}' not found.")
    except PermissionError:
        print(f"Error: Permission denied for '{directory}'.")
    except OSError as e:
        print(f"Error: {e}")


    if len(sys.argv) < 3:
        sys.exit(1)

    target_directory = sys.argv[1]
    target_extension = sys.argv[2]

    display_file_contents(target_directory, target_extension)
    rename_files_with_sequence(target_directory)
    calculate_total_directory_size(target_directory)
    count_files_by_extension(target_directory)
