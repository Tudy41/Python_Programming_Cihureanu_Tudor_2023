print("ex1:\n")


def gcd(a, b):
    c = 0
    while b != 0:
        c = a % b
        a = b
        b = c

    return a


numbersasstrings = input("Enter the numbers: ").split()

numbersasintegers = list()

for i in numbersasstrings:
    numbersasintegers.append(int(i))

gcdfinal = numbersasintegers[0]

for i in numbersasintegers[1:]:
    gcdfinal = gcd(gcdfinal, i)

print(gcdfinal)

print('\n')
print('ex2:\n')


def count_vowels(string):
    vowels = "aeiouAEIOU"
    total = 0

    for i in string:
        if i in vowels:
            total += 1

    return total


string = input("enter the string: ")
total = count_vowels(string)

print(total)

print('\n')
print('ex3:\n')

string1 = input("Enter the first string: \n")
string2 = input("Enter the second string: \n")

print(string2.count(string1))

print('\n')
print('ex4:\n')


def f(string):
    result = list()
    result = [string[0].lower()]

    for i in string[1:]:
        if i.isupper():

            result.append('_')
            result.append(i.lower())
        else:
            result.append(i)

    return ''.join(result)


string = input("Enter the string: ")

string = f(string)
print(string)

print('\n')
print('ex5:\n')

m = [
    ["f", "i", "r", "s"],
    ["n", "_", "l", "t"],
    ["o", "b", "a", "_"],
    ["h", "t", "y", "p"]
]

msg = []

while m:

    msg.extend(m.pop(0))

    for i in m:
        msg.append(i.pop())

    if m:
        msg.extend(m.pop()[::-1])

    for i in m[::-1]:
        msg.append(i.pop(0))

print("".join(msg))

print('\n')
print('ex6:\n')


def palindrome(n):
    m = 0
    n2 = n
    while n:
        m = m * 10 + n % 10
        n = n // 10

    if n2 == m:
        return 1
    else:
        return 0


string = input("Enter the number(for 6): ")

if palindrome(int(string)) == 1:
    print("Este palindrom")
else:
    print("Nu este palindrom")

print('\n')
print('ex7:\n')


def getnr(n):
    saver = 0
    thenr = ''
    nr = 0
    ok = 0
    for i in n:
        if i.isdigit():
            thenr += i
            ok = 1
        elif ok == 1:
            break;

    return thenr


string = input("Enter the number(for 7): ")

print(getnr(string))

print('\n')
print('ex8:\n')


def getnrbits(n):
    nr = 0
    while n:

        if n % 2 == 1:
            nr = nr + 1

        n = n // 2
    return nr


string = input("Enter the number(for 8): ")
print(getnrbits(int(string)))

print('\n')
print('ex9:\n')


def f(string):
    string = string.lower()

    d = dict()

    for i in string:

        if i.isalpha():
            if i in d:
                d[i] += 1
            else:
                d[i] = 1

    maxim = -999
    letter = 0
    for i in d.keys():
        if d.get(i) > maxim:
            maxim = d.get(i)
            letter = i

    return [letter, maxim]


string = input("enter the number(for 9): ")
print(f(string))

print('\n')
print('ex10:\n')


def f(n):
    nr = 0
    reachedaword = False
    for i in n:
        if i.isalpha() and reachedaword==False:
            nr = nr + 1
            reachedaword = True
        elif i == ' ':
            reachedaword = False

    if n[len(n)-1].isalpha() and reachedaword!=True:
        nr=nr+1
    return nr


string = input("enter the string(for 10): ")
print(f(string))
