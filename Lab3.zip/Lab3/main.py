print("ex1:\n")
def f(l1, l2):
    inter = set(l1) & set(l2)
    union = set(l1) | set(l2)
    a_b = set(l1) - set(l2)
    b_a = set(l2) - set(l1)
    return [inter, union, a_b, b_a]


l1 = [1, 2, 3, 4]
l2 = [3, 4, 5, 6]
result = f(l1, l2)
print(result)

print("ex2:\n")
def nr(string):
    dict = {}
    for c in string:
        if c.isalnum():
            dict[c] = dict.get(c, 0) + 1
    return dict


string = "Ana has apples."
char_countdict = nr(string)
print(char_countdict)

print("ex3:\n")
def compare(dict1, dict2):
    if len(dict1) != len(dict2):
        return False
    for key, value in dict1.items():
        if key not in dict2:
            return False
        if isinstance(value, dict):
            if not compare(value, dict2[key]):
                return False
        elif value != dict2[key]:
            return False
    return True

dict1 = {"a": 1, "b": {"c": 2, "d": 3}}
dict2 = {"b": {"d": 3, "c": 2}, "a": 1}
print(compare(dict1, dict2))

print("ex4:\n")
def build_xml(tag, content, **kwargs):
    attributes = ' '.join([f'{key}="{value}"' for key, value in kwargs.items()])
    return f'<{tag} {attributes}>{content}</{tag}>'


xml = build_xml("a", "Hello there", href="http://python.org", _class="my-link", id="someid")
print(xml)

print("ex5:\n")
def validate_dict(rules, dictionary):
    for key, prefix, middle, suffix in rules:
        if key in dictionary:
            value = dictionary[key]
            if (prefix and not value.startswith(prefix)) or (suffix and not value.endswith(suffix)):
                return False

            if middle and middle not in value[1:-1]:
                return False
        else:
            return False

    return True


rules = {("key1", "", "inside", ""), ("key2", "start", "middle", "winter")}
d = {"key1": "come inside, it's too cold out", "key3": "this is not valid"}

result = validate_dict(rules, d)
print(result)

print("ex6:\n")
def count(lst):
    uniq = set()
    dup = set()
    for item in lst:
        if lst.count(item) == 1:
            uniq.add(item)
        elif item not in uniq:
            dup.add(item)
    return len(uniq), len(dup)


list = [1, 2, 2, 3, 4, 4, 5]
result = count(list)
print(result)

print("ex7:\n")
def operations(*args):
    result = {}
    operations = ['|', '&', '-', '^']
    for i in range(len(args)):
        for j in range(i + 1, len(args)):
            for op in operations:
                key = f"{args[i]} {op} {args[j]}"
                if op == '|':
                    result[key] = args[i] | args[j]
                elif op == '&':
                    result[key] = args[i] & args[j]
                elif op == '-':
                    result[key] = args[i] - args[j]
                elif op == '^':
                    result[key] = args[i] ^ args[j]
    return result


set1 = {1, 2}
set2 = {2, 3}
dict = operations(set1, set2)
print(dict)

print("ex10:\n")
def f(m):
    visited = set()
    result = []
    key = "start"
    while key not in visited and key in m:
        visited.add(key)
        if key !="start":
            result.append(key)
        key = m[key]
    return result


m = {'start': 'a', 'b': 'a', 'a': '6', '6': 'z', 'x': '2', 'z': '2', '2': '2', 'y': 'start'}
result = f(m)
print(result)

print("ex111:\n")
def countmatching(*args, **kwargs):
    values = set(kwargs.values())
    count = sum(1 for arg in args if arg in values)
    return count


count = countmatching(1, 2, 3, 4, x=1, y=2, z=3, w=5)
print(count)