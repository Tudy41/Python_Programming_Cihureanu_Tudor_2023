class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()
        return None

    def peek(self):
        if not self.is_empty():
            return self.items[-1]
        return None

    def is_empty(self):
        return len(self.items) == 0


class Queue:
    def __init__(self):
        self.items = []

    def push(self, item):

        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop(0)
        return None

    def peek(self):
        if not self.is_empty():
            return self.items[0]
        return None

    def is_empty(self):
        return len(self.items) == 0


class Matrix:

    def __init__(self, rows, columns):
        self.rows = rows
        self.columns = columns
        self.data = [[0] * columns for _ in range(rows)]

    def get(self, row, col):
        if 0 <= row < self.rows and 0 <= col < self.columns:
            return self.data[row][col]
        return None

    def set(self, row, col, value):
        if 0 <= row < self.rows and 0 <= col < self.columns:
            self.data[row][col] = value

    def transpose(self):
        transposed_matrix = Matrix(self.columns, self.rows)
        for i in range(self.rows):
            for j in range(self.columns):
                transposed_matrix.set(j, i, self.get(i, j))
        return transposed_matrix

    def matrix_multiplication(self, other_matrix):

        if self.columns != other_matrix.rows:
            return None

        result = Matrix(self.rows, other_matrix.columns)
        for i in range(self.rows):
            for j in range(other_matrix.columns):
                for k in range(self.columns):
                    result.data[i][j] += self.data[i][k] * other_matrix.data[k][j]
        return result

    def iterate_and_transform(self, func):
        for i in range(self.rows):
            for j in range(self.columns):
                self.data[i][j] = func(self.data[i][j])


stack = Stack()

stack.push(1)
stack.push(2)
print(stack.pop())

queue = Queue()

queue.push(3)
queue.push(4)

print(queue.pop())

matrix = Matrix(2, 2)
matrix.set(0, 0, 1)
matrix.set(0, 1, 2)
matrix.set(1, 0, 3)
matrix.set(1, 1, 4)

transposed = matrix.transpose()
print(transposed.data)

matrix2 = Matrix(2, 2)
matrix2.set(0, 0, 2)
matrix2.set(0, 1, 1)
matrix2.set(1, 0, 4)
matrix2.set(1, 1, 3)

result = matrix.matrix_multiplication(matrix2)
print(result.data)

matrix.iterate_and_transform(lambda x: x * 2)
print(matrix.data)
